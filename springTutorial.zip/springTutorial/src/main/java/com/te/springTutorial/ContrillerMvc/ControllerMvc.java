package com.te.springTutorial.ContrillerMvc;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

public class ControllerMvc {
	@RequestMapping(path="/hello",method=RequestMethod.GET)
	public ModelAndView getscience()
	{
		ModelAndView modelAndview=new ModelAndView();
		modelAndview.setViewName("/WEB-INF/views/science.jsp");
		return modelAndview;
		
	}
	@RequestMapping(path="/movies",method=RequestMethod.GET)
	public ModelAndView getHome(ModelAndView modelAndview,HttpServletRequest request)
	{
		String movies=request.getParameter("movies");
		modelAndview.addObject("movies",movies);
		modelAndview.setViewName("/WEB-INF/views/movies.jsp");
		return modelAndview;
		
	}
	@RequestMapping(path="/sports",method=RequestMethod.GET)
	public ModelAndView getSearch(ModelAndView modelAndview,HttpServletRequest request)
	{
		modelAndview.setViewName("/WEB-INF/views/sports.jsp");
		return modelAndview;
		  
	}
}
